<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/riverside/templates/page/page.html.twig */
class __TwigTemplate_ab3c3e4b0adc917c9bf76fadd1880288 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 42
        yield "<main>
\t<div class=\"visually-hidden\">
\t\t<a id=\"main-content\" tabindex=\"-1\"></a>
\t</div>
\t";
        // line 46
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "breadcrumb", [], "any", false, false, true, 46) || CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header", [], "any", false, false, true, 46))) {
            // line 47
            yield "\t\t<header class=\"content-header clearfix\">
\t\t\t<div class=\"layout-container\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<div class=\"main-menu\">
\t\t\t\t\t\t<h2>
\t\t\t\t\t\t\t<a href=\"/\">Riverside Commans</a>
\t\t\t\t\t\t</h2>
\t\t\t\t\t\t";
            // line 54
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header", [], "any", false, false, true, 54), "html", null, true);
            yield "
\t\t\t\t\t\t<button class=\"menu-icon\" id=\"mobileMenu\" aria-expanded=\"false\" aria-controls=\"mobile-navigation\" aria-label=\"Open navigation menu\">
\t\t\t\t\t\t\t<span></span>
\t\t\t\t\t\t\t<span></span>
\t\t\t\t\t\t\t<span></span>
\t\t\t\t\t\t</button>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</header>
\t";
        }
        // line 65
        yield "\t";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "breadcrumb", [], "any", false, false, true, 65), "html", null, true);
        yield "

\t<div class=\"layout-container\">
\t\t";
        // line 68
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "pre_content", [], "any", false, false, true, 68), "html", null, true);
        yield "
\t\t<div class=\"page-content clearfix\">
\t\t\t";
        // line 70
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "highlighted", [], "any", false, false, true, 70), "html", null, true);
        yield "
\t\t\t";
        // line 71
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "help", [], "any", false, false, true, 71)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 72
            yield "\t\t\t\t<div class=\"help\">
\t\t\t\t\t";
            // line 73
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "help", [], "any", false, false, true, 73), "html", null, true);
            yield "
\t\t\t\t</div>
\t\t\t";
        }
        // line 76
        yield "\t\t\t";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 76), "html", null, true);
        yield "
\t\t</div>

\t</div>

\t<footer>
\t\t<div class=\"container\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"main-box\">
\t\t\t\t\t<div class=\"region\">
\t\t\t\t\t\t<div class=\"box\">
\t\t\t\t\t\t\t<div class=\"content\">
\t\t\t\t\t\t\t\t<h3>Riverside Commons</h3>
\t\t\t\t\t\t\t\t<p>14 Mill Street</p>
\t\t\t\t\t\t\t\t<p>Riverfront District</p>
\t\t\t\t\t\t\t\t<p>Open Tue–Sun</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t";
        // line 95
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_grid_2", [], "any", false, false, true, 95), "html", null, true);
        yield "
\t\t\t\t\t";
        // line 96
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_grid_3", [], "any", false, false, true, 96), "html", null, true);
        yield "
\t\t\t\t\t";
        // line 97
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_grid_4", [], "any", false, false, true, 97), "html", null, true);
        yield "
\t\t\t\t</div>
\t\t\t\t<div class=\"sub-footer\">
\t\t\t\t\t<p>© 2026 Riverside Commons</p>
\t\t\t\t\t<ul>
\t\t\t\t\t\t<li><a href=\"#\">Instagram</a></li>
\t\t\t\t\t\t<li><a href=\"#\">Facebook</a></li>
\t\t\t\t\t\t<li><a href=\"#\">Newsletter</a></li>
\t\t\t\t\t</ul>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</footer>
</main>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["page"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/riverside/templates/page/page.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  132 => 97,  128 => 96,  124 => 95,  101 => 76,  95 => 73,  92 => 72,  90 => 71,  86 => 70,  81 => 68,  74 => 65,  60 => 54,  51 => 47,  49 => 46,  43 => 42,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/custom/riverside/templates/page/page.html.twig", "/var/www/html/web/themes/custom/riverside/templates/page/page.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 46];
        static $filters = ["escape" => 54];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "if"],
                [0 => "escape"],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
