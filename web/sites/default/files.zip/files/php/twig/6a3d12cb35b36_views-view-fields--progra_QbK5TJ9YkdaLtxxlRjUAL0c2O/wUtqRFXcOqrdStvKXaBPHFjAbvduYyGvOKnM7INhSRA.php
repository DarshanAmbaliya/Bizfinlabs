<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/riverside/templates/views/views-view-fields--program.html.twig */
class __TwigTemplate_344ca6a2a8e38e637d41057b7323bc4c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 34
        $context["start"] = $this->extensions['Twig\Extension\CoreExtension']->formatDate(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["row"] ?? null), "_entity", [], "any", false, false, true, 34), "field_schedule", [], "any", false, false, true, 34), "value", [], "any", false, false, true, 34), "U");
        // line 35
        $context["end"] = $this->extensions['Twig\Extension\CoreExtension']->formatDate(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["row"] ?? null), "_entity", [], "any", false, false, true, 35), "field_schedule", [], "any", false, false, true, 35), "end_value", [], "any", false, false, true, 35), "U");
        // line 36
        $context["weeks"] = (Twig\Extension\CoreExtension::round(((($context["end"] ?? null) - ($context["start"] ?? null)) / 604800), 0, "floor") + 1);
        // line 37
        yield "
<div class=\"box\">
\t<div class=\"content\">
\t\t<div class=\"image\">
\t\t\t";
        // line 41
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["fields"] ?? null), "field_media", [], "any", false, false, true, 41), "content", [], "any", false, false, true, 41), "html", null, true);
        yield "
\t\t</div>
\t\t<div class=\"detail\">
\t\t\t<div class=\"category\">
\t\t\t\t<p>";
        // line 45
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["fields"] ?? null), "field_category", [], "any", false, false, true, 45), "content", [], "any", false, false, true, 45), "html", null, true);
        yield "</p>
\t\t\t</div>
\t\t\t<h3>";
        // line 47
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["fields"] ?? null), "title", [], "any", false, false, true, 47), "content", [], "any", false, false, true, 47), "html", null, true);
        yield "</h3>
\t\t\t<div class=\"short-description\">
\t\t\t\t<p>";
        // line 49
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["fields"] ?? null), "field_short_description", [], "any", false, false, true, 49), "content", [], "any", false, false, true, 49), "html", null, true);
        yield "</p>
\t\t\t</div>
\t\t\t<div class=\"meta-detail\">
\t\t\t\t<p>";
        // line 52
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["weeks"] ?? null), "html", null, true);
        yield " weeks · ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["session_time_short"] ?? null), "html", null, true);
        yield " · ";
        yield (((Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["fields"] ?? null), "field_price", [], "any", false, false, true, 52), "content", [], "any", false, false, true, 52)) || (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["fields"] ?? null), "field_price", [], "any", false, false, true, 52), "content", [], "any", false, false, true, 52) == "0"))) ? ("Free entry") : ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ("\$" . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["fields"] ?? null), "field_price", [], "any", false, false, true, 52), "content", [], "any", false, false, true, 52)), "html", null, true)));
        yield "</p>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["row", "fields", "session_time_short"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/riverside/templates/views/views-view-fields--program.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  78 => 52,  72 => 49,  67 => 47,  62 => 45,  55 => 41,  49 => 37,  47 => 36,  45 => 35,  43 => 34,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/custom/riverside/templates/views/views-view-fields--program.html.twig", "/var/www/html/web/themes/custom/riverside/templates/views/views-view-fields--program.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 34];
        static $filters = ["date" => 34, "round" => 36, "escape" => 41];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "set"],
                [0 => "date", 1 => "round", 2 => "escape"],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
